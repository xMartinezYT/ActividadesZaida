package com.dam.javi;
import java.util.ArrayList;
import java.util.Scanner;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream.Filter;


public class main {

	public static void main(String[] args) throws IOException {
	

		
		
		ejercicio7(args);
		
		
		
		
	}
	
public static void ejercicio1(String[] args) {
	
		
	
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Dime la ruta que deseas introducir");
		
		String Introducirdirectorio = teclado.nextLine();
		
		File directorio = new File(Introducirdirectorio);
		
	
		System.out.println(directorio.getAbsolutePath());
		
}

	public static void ejercicio2(String[] args) {
	
		Scanner teclado = new Scanner(System.in);
	
		System.out.println("Dime la ruta que deseas introducir");
		String Introducirdirectorio = teclado.nextLine();
		
		File directorio = new File(Introducirdirectorio);
		
		
		System.out.println("Se llama " + directorio.getName());
		System.out.println("La ruta completa es  " + directorio.getAbsolutePath());
		System.out.println("Se puede leer? " + directorio.canWrite());
		System.out.println("Tamaño del directorio " + directorio.length());
		
		
		
	}
	
public static void ejercicio3(String[] args) {
	
		
	Scanner teclado = new Scanner(System.in);
	
	System.out.println("Dime la ruta que deseas introducir");
	String Introducirdirectorio = teclado.nextLine();
	
	File directorio = new File(Introducirdirectorio);
		
		if (directorio.exists() ) {
			System.out.println("Existe");
		
			System.out.println("Se llama " + directorio.getName());
			System.out.println("La ruta completa es  " + directorio.getAbsolutePath());
			System.out.println("Se puede leer? " + directorio.canWrite());
			System.out.println("Tamaño del directorio " + directorio.length());
			
			
			 
	
		}else {
			System.out.println("El directorio no existe");
		}
		
		
	
		
      	
		
		
		
		
	}

public static void ejercicio4(String[] args) {
	
	
	Scanner teclado = new Scanner(System.in);
	
	System.out.println("Dime la ruta que deseas introducir");
	String Introducirdirectorio = teclado.nextLine();
	
	File directorio = new File(Introducirdirectorio);
		
		if (directorio.exists() ) {
			System.out.println("Existe");
		
			System.out.println("Se llama " + directorio.getName());
			System.out.println("La ruta completa es  " + directorio.getAbsolutePath());
			System.out.println("Se puede leer? " + directorio.canWrite());
			System.out.println("Tamaño del directorio " + directorio.length());
			
			
			 
	
		}else {
			System.out.println("El directorio no existe");
		}
		
		
	
		
      	
		
		
		
		
	}




public static void ejercicio5(String[] args) {

	
	

Scanner teclado = new Scanner(System.in);
	
	System.out.println("Dime la ruta que deseas introducir");
	String Introducirdirectorio = teclado.nextLine();
	
	File directorio = new File(Introducirdirectorio);
	
	

	System.out.println("Dime que ficheros deseas ver por pantalla");
	String verficheros = teclado.nextLine();
	
	Filtro extension = new Filtro(verficheros);
	
	
	File[] archivos = directorio.listFiles(extension);;
	

	
	  for (File archivo : archivos) {
		  
          System.out.println(archivo.getName());
      
  }
	   
	   
}

public static void ejercicio6(String[] args) {
	
	
Scanner teclado = new Scanner(System.in);
	
	System.out.println("Dime la ruta que deseas introducir");
	String Introducirdirectorio = teclado.nextLine();
	
	File directorio = new File(Introducirdirectorio);
	
	

	System.out.println("Dime que ficheros deseas ver por pantalla");
	String verficheros = teclado.nextLine();
	
	Filtro extension = new Filtro(verficheros);
	
	
	File[] archivos;
	
	if(extension != null) {
		
	
	archivos = directorio.listFiles(extension);
	
 }else {
	 
	 archivos = directorio.listFiles();
	
}
	
	  for (File archivo : archivos) {
		  
          System.out.println(archivo.getName());
      
  }
	   
	   
}

public static void ejercicio7(String[] args) {


	Scanner teclado = new Scanner(System.in);
	
	System.out.println("Dime la ruta que deseas introducir");
	String Introducirdirectorio = teclado.nextLine();
	
	File directorio = new File(Introducirdirectorio);
	
	ArrayList<Filtro> filtros = new ArrayList<>();
	
	String verficheros;
	
	System.out.println("añade extensiones para filtrar, selecciona 0 para dejar de añadir");
	
	do {
		
		verficheros = teclado.nextLine();
		
		Filtro extension = new Filtro(verficheros);
		filtros.add(extension);
		
		
	}while(!verficheros.equals("0"));


	
	
	
	
	
	  for (Filtro filtro : filtros) {
		  
		  File[] archivos = directorio.listFiles(filtro);
		  for (File archivo : archivos) {
		  System.out.println(archivo.getName());
		  }
  }
}

public static void ejercicio8(String[] args) throws IOException {
	
	
	Scanner teclado = new Scanner(System.in);
	
	System.out.println("Dime la ruta que deseas introducir");
	String Introducirdirectorio = teclado.nextLine();
	
	File directorio = new File(Introducirdirectorio);
	

	System.out.println("Dime que ficheros deseas copiar");
	String ficheroacopiar = teclado.nextLine();
	
	
	
	File[] archivos = directorio.listFiles();
	
	
	   for (File archivo : archivos) {
		
		   
           if (archivo.getName().equals(ficheroacopiar)) {
        	  
        	   File archivoCopia = new File(directorio, "copia_" + archivo.getName());
        	   System.out.println("El pepe copiado con éxito");
        	   
        	   archivoCopia.createNewFile();
        	   
        	   
        	   archivo.delete();
        	   break;
        	   
           }
	   }
	   
	   
}

}
       
    
	  
			 
		
      	
		
		
	
