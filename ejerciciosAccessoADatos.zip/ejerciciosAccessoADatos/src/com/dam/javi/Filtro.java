package com.dam.javi;

import java.io.File;
import java.io.FilenameFilter;

public class Filtro implements FilenameFilter{

	
	
	String extension;
	
	
	
	public Filtro (String filtro) {
		
		this.extension = filtro;
		
	}



	@Override
	public boolean accept(File dir, String name) {
		// TODO Auto-generated method stub
		return name.endsWith(extension);
	}


	
	
	
}
