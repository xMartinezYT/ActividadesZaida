package com.dam.java;

import java.util.Scanner;
import java.util.Random;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Dime el dia en que naciste");
		
		
		int dia = teclado.nextInt();
		
		
		System.out.println("Ahora el mes");
		
		int mes = teclado.nextInt();
		
		
		String signoCeliaco = obtenirSigneZodiacal(dia,mes);
		
		
		String frasedelCeliaco = fraseRandomDelCeliaco();
		
		System.out.println("Tu signo del Celiaco es " + signoCeliaco + " la prediccion de hoy: " + frasedelCeliaco);
		
		
		
		
	}
	 public static String obtenirSigneZodiacal(int dia, int mes) {
		 
		 	if ((mes == 3 && dia >= 21) || (mes == 4 && dia <= 20)) return "Aries";
	        if ((mes == 4 && dia >= 21) || (mes == 5 && dia <= 20)) return "Tauro";
	        if ((mes == 5 && dia >= 21) || (mes == 6 && dia <= 20)) return "Géminis";
	        if ((mes == 6 && dia >= 21) || (mes == 7 && dia <= 22)) return "Cáncer";
	        if ((mes == 7 && dia >= 23) || (mes == 8 && dia <= 22)) return "Leo";
	        if ((mes == 8 && dia >= 23) || (mes == 9 && dia <= 22)) return "Virgo";
	        if ((mes == 9 && dia >= 23) || (mes == 10 && dia <= 22)) return "Libra";
	        if ((mes == 10 && dia >= 23) || (mes == 11 && dia <= 21)) return "Escorpio";
	        if ((mes == 11 && dia >= 22) || (mes == 12 && dia <= 21)) return "Sagitario";
	        if ((mes == 12 && dia >= 22) || (mes == 1 && dia <= 19)) return "Capricornio";
	        if ((mes == 1 && dia >= 20) || (mes == 2 && dia <= 18)) return "Acuario";
	        return "Piscis"; 
	 }
	 
	 
	 public static String fraseRandomDelCeliaco () {
		
		 String[] prediccions = {
		            "Oh no! hoy serás Celiaco por primera vez en tu vida",
		            "Esta semana tus padres estarán un poco anormalmente enfadados",
		            "Te vas a forrar esta semana mi rey",
		            "Verás una oportunidad unica, yo la aprovecharía jeje ",
		            "Hoy es el dia perfecto para que te quedes en casa la verdad.",
		            "Vas a encontar al amor de tu vida te lo juro "
		        };
		 
		 
		 Random random = new Random();
	        int numeroRandom = random.nextInt(prediccions.length);
	        return prediccions[numeroRandom];
		 
		 
		 
		 
	 }
	
	
	
}


