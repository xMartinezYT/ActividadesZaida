package com.dam.javi;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		
		campeon c1 = new campeon("Aatrox","Tirador");
		campeon c2 = new campeon("Ahri","Mago");
		campeon c3 = new campeon();
		
		habilidad h1 = new habilidad("Justiciero","Atrox usa el ataque de la justicia!",10);
		habilidad h2 = new habilidad("Mecha","Atrox usa el ataque de la justicia!",20);
		habilidad h3 = new habilidad("cazador marino","Atrox usa el ataque de la justicia!",30);

		habilidad h4 = new habilidad("Medianoche","Ahri te mata de amor",10);
		habilidad h5 = new habilidad("Estrellapop","Ahri te mata de amor",20);
		habilidad h6 = new habilidad("Retadora marino","Ahri te mata de amor",30);

		habilidad h7 = new habilidad();
		habilidad h8= new habilidad();
		habilidad h9 = new habilidad();
		
		
		habilidad[] habilidadesAtrox = new habilidad[3];
		
		habilidadesAtrox[0] = h1;
		habilidadesAtrox[1] = h2;
		habilidadesAtrox[2] = h3;
		

		c1.setHabilidades(habilidadesAtrox);
		
		
		habilidad[] habilidadesAhri = new habilidad[3];
		
		habilidadesAhri[0] = h4;
		habilidadesAhri[1] = h5;
		habilidadesAhri[2] = h6;
		
		c2.setHabilidades(habilidadesAhri);
		
		habilidad[] habilidadesnuevo = new habilidad[3];
		
		habilidadesnuevo[0] = h7;
		habilidadesnuevo[1] = h8;
		habilidadesnuevo[2] = h9;
		
		
		
		campeon[] campeones = new campeon[2];
		campeones[0] = c1;
		campeones[1] = c2;
		
		int seleccion = 0;
		do {
			
			System.out.println();
			System.out.println("BIENVENIDO A XUQUER LEGENDS");
			System.out.println("1 VER CAMPEONES");
			System.out.println("2 VER CAMPEONES CON SUS HABILIDADES");
			System.out.println("3 AÑADIR CAMPEON");
			System.out.println("4 SALIR DEL JUEGO");
			
			seleccion = teclado.nextInt();
			
			switch (seleccion) {
			
			case 1: 
				System.out.println();
				mostrarCampeones(campeones);
				
				break;
			
			case 2:
				
				mostrarCampeonesyHabilidades(campeones);
				System.out.println();
				
				break;
				
			case 3:
				
				System.out.println("Nombre del campeon");
				String nuevocampeon = teclado.nextLine();
				teclado.nextLine();
				
				c3.setNombre(nuevocampeon);
				
				for (int i = 0 ; i<habilidadesnuevo.length;i++) {
					
				System.out.println("habilidad " + (i+1));
				
				String habilidad = teclado.nextLine();
				habilidadesnuevo[i].setNombre(habilidad);
				
				}
				
				
				break;
				
			case 4:
				System.out.println("Saliendo del videjuego!");
				
				break;
			}
			
			
			
			
			
	
			
			
			
			
			
		}while(seleccion != 4);
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	public static void mostrarCampeones(campeon[] campeones) {
		
		for(int i = 0;i<campeones.length;i++) {
			
			
			System.out.println("Campeon  "  + (i+1) +" ");
			System.out.println(campeones[i].getNombre() +" rol " + campeones[i].getRol() );
			
		}
		
		
	}
	public static void mostrarCampeonesyHabilidades(campeon campeones[]) {
		
		
	
		
		
		for(int i=0;i<campeones.length;i++) {
			System.out.println(campeones[i].getNombre());
			
			
			
			
			for(int j=0;j<3;j++) {
			System.out.println("Habilidad" + " " + (j+1) + " " + campeones[i].habilidades[j].getNombre());
			
			
		}
			System.out.println();
		}
		
		
		
	}

}
