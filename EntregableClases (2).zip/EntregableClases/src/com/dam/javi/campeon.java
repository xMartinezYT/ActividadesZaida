package com.dam.javi;

import com.dam.java.cancion;

public class campeon {

	
	
	
	
	private String nombre;
	private String rol;
	private int vida;
	private int magia ;
	
	habilidad[] habilidades = new habilidad[3];
	campeon[] campeones = new campeon[2];
	
	
	
	public campeon(String n,String r) {
		
		this.nombre = n;
		this.rol = r;
		
		this.vida = 100;
		this.magia = 0;
		
		
		
		
		
	}
	
	
	
	
	
	
	public campeon() {
		// TODO Auto-generated constructor stub
	}






	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getRol() {
		return rol;
	}

	public void setRol(String rol) {
		this.rol = rol;
	}

	public int getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}

	public int getMagia() {
		return magia;
	}

	public void setMagia(int magia) {
		this.magia = magia;
	}
	
	
	public static void ataque (campeon contrincante ) {
		
		
		switch (contrincante.getRol()) {
		
		case "asesino":
			contrincante.setVida(-20);
		break;
		case "luchador":
			contrincante.setVida(-10);
		break;
		case "mago":
			contrincante.setVida(-5);
		break;
		case "tirador":
			contrincante.setVida(-15);
		break;
		case "soporte":
			contrincante.setVida(-25);
		break;
		case "tanque":
			contrincante.setVida(-30);
		break;
		
		}
		
		
	}
	public void setHabilidades(habilidad[] habilidades) {
		this.habilidades = habilidades;
	}
	
	
	
	
	
	
}