package com.dam.java;
import java.util.ArrayList;
import java.util.Scanner;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream.Filter;
import java.text.SimpleDateFormat;


public class main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		
		 Scanner teclado = new Scanner(System.in);
		
		 int numeroIntroducido;
		 
		do {
			
		
		System.out.println("BIENVENIDO AL XUQUERGESTOR QUE DESEA HACER ");
		System.out.println("1- Ver información de cierto directorio ");
		System.out.println("2- Crear directorios ");
		System.out.println("3- Crea archivos (antes crearás un nuevo directorio)  ");
		System.out.println("4- Renombra ficheros o directorios  ");
		System.out.println("5- elimina ficheros o directorios  ");
		System.out.println("6- Salir ");
		
		numeroIntroducido = teclado.nextInt();
		
		switch (numeroIntroducido) {
		case 1:
			getInformacio();
			break;
		
		case 2:
			creaCarpeta();
			
			break;
		case 3 : 
			
			File directorionuevo = creaCarpeta();
			
			creaArchivo(directorionuevo);
		
			break;
		
		case 4 : 
			eliminador();
			
			break;
			
		case 5: 
			
			renombrador();
			break;
			
		default:
			System.out.println("Introduce un numero correcto");
			break;
		}
		
		
		
		
		
		}while(numeroIntroducido != 6);
		
		
		
	}
	
	
	
	
	
	public static void getInformacio() {
		 Scanner teclado = new Scanner(System.in);

	        System.out.println("Dime la ruta que deseas introducir:");
	        String Introducirdirectorio = teclado.nextLine();

	        File directorio = new File(Introducirdirectorio);

	       
	        System.out.println("Nombre: " + directorio.getName());

	      
	        if (directorio.isFile()) {
	            System.out.println("Es un fichero");
	        } else if (directorio.isDirectory()) {
	            System.out.println("Es un directorio");
	        }

	        
	        System.out.println("Ruta completa: " + directorio.getAbsolutePath());

	       
	        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	        System.out.println("Última modificación: " + sdf.format(directorio.lastModified()));

	        
	        System.out.println("Es oculto: " + (directorio.isHidden() ? "Sí" : "No"));

	        
	        if (directorio.isFile()) {
	            System.out.println("Tamaño en bytes: " + directorio.length());
	        }

	       
	        if (directorio.isDirectory()) {
	            String[] elementos = directorio.list();
	            System.out.println("Número de elementos en el directorio: " + elementos.length);

	            System.out.println("Espacio libre: " + directorio.getFreeSpace() + " bytes");
	            System.out.println("Espacio disponible: " + directorio.getUsableSpace() + " bytes");
	            System.out.println("Espacio total: " + directorio.getTotalSpace() + " bytes");
	        }
	        
	        
	        controlaPermisos(directorio);
		
	}
	
	
	public static File creaCarpeta() {
      
		
		 Scanner teclado = new Scanner(System.in);

		
		String rutaDirectorio, nombreCarpeta;
		
		System.out.println("Dime donde quieres crear la carpeta ");
		
		rutaDirectorio = teclado.nextLine();

		
		System.out.println("que nombre tendrá la carpeta?? ");
		
		nombreCarpeta = teclado.nextLine();
		
		
        File nuevaCarpeta = new File(rutaDirectorio, nombreCarpeta);

    
        
        
        if (nuevaCarpeta.exists()) {
            System.out.println("La carpeta ya existe en el directorio.");
        } else {
            if (nuevaCarpeta.mkdirs()) {
                System.out.println("Carpeta creada con éxito en la ruta: " + nuevaCarpeta.getAbsolutePath());
            } else {
                System.out.println("Error al crear la carpeta.");
            }
        }

        
        controlaPermisos(nuevaCarpeta);
        
        return nuevaCarpeta;
        
    }

	public static void creaArchivo(File nuevaCarpeta) throws IOException {
	      
		
		 Scanner teclado = new Scanner(System.in);

		
		 System.out.println("Como se va a llamar el archivo (pon tambien el formato)");
	
		 String nombreArchivo = teclado.nextLine();
		
		
       File nuevoArchivo = new File(nuevaCarpeta.getAbsolutePath(),nombreArchivo);
       
       nuevoArchivo.createNewFile();      
       controlaPermisos(nuevoArchivo);
   
       
   }
	
	
	public static void eliminador() {
		 Scanner teclado = new Scanner(System.in);
		 
		 System.out.println("Introduce la ruta del archivo o carpeta que deseas eliminar:");
	        String rutaOriginal = teclado.nextLine();
	      
	        
	        File archivoOriginal = new File(rutaOriginal);

	     
	        if (archivoOriginal.isDirectory()) {
	            File[] archivos = archivoOriginal.listFiles();
	            if (archivos != null) {
	                for (File f : archivos) {
	                    f.delete();
	                }
	            }
	        }else if (archivoOriginal.isFile()){

		        archivoOriginal.delete();
	        }

	       
	      
	    
	        
	        
	        controlaPermisos(archivoOriginal);
	}
	
	public static void renombrador() {
		 Scanner teclado = new Scanner(System.in);
		 
		 System.out.println("Introduce la ruta del archivo o carpeta que deseas renombrar:");
	        String rutaOriginal = teclado.nextLine();
	      
	        
	        File archivoOriginal = new File(rutaOriginal);

	        if (!archivoOriginal.exists()) {
	            System.out.println("El archivo o carpeta no existe en la ruta proporcionada.");
	            return;
	        }
	        
	        
	        System.out.println("Dime el nuevo nombre que deseas ponerle ");
	       
	        String nuevoNombre = teclado.nextLine();
	        
	        File directorioPadre = archivoOriginal.getParentFile();

	        File archivoRenombrado = new File(directorioPadre, nuevoNombre);
	        
	        
	        if (archivoOriginal.renameTo(archivoRenombrado)) {
	            System.out.println("Archivo o carpeta renombrado con éxito a: " + archivoRenombrado.getAbsolutePath());
	        } else {
	            System.out.println("Error al renombrar el archivo o carpeta.");
	        }
	        
	        
	        controlaPermisos(archivoRenombrado);
	}
	
	
	
	
	
	
	 public static void controlaPermisos(File archivo) {
	        System.out.println("Permisos para el archivo/carpeta: " + archivo.getName());

	     
	        if (archivo.canRead()) {
	            System.out.println("- Permiso de lectura: Sí");
	        } else {
	            System.out.println("- Permiso de lectura: No");
	        }

	       
	        if (archivo.canWrite()) {
	            System.out.println("- Permiso de escritura: Sí");
	        } else {
	            System.out.println("- Permiso de escritura: No");
	        }

	      
	        if (archivo.canExecute()) {
	            System.out.println("- Permiso de ejecución: Sí");
	        } else {
	            System.out.println("- Permiso de ejecución: No");
	        }
	    }
	
}
